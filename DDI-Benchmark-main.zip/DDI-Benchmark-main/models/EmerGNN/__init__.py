from .DrugBank.evaluate import run_emergnn_drugbank
from .TWOSIDES.evaluate import run_emergnn_twosides