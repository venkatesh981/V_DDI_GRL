from .KG_DDI_pretrain import KGDDI_pretrain
from .model import KGDDI_MLP